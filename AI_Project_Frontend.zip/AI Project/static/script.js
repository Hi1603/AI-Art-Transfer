const canvas = document.getElementById('artCanvas');
const ctx = canvas.getContext('2d');

let currentColor = '#000000';
let isDrawing = false;
let uploadedImage = null;

let brushSize = 5;
let brushType = 'normal';

const colorPicker = document.getElementById('colorPicker');
const brushSlider = document.getElementById('brushSize');
const brushSelector = document.getElementById('brushType');
const messageDiv = document.getElementById('message');
const open3DViewerBtn = document.getElementById('open3DViewer');
const download3DLink = document.getElementById('download3DLink');

let lastGeneratedModel = "output_3d.glb";  // fallback

// Brush controls
brushSlider.addEventListener('input', () => {
  brushSize = parseInt(brushSlider.value);
});
brushSelector.addEventListener('change', () => {
  brushType = brushSelector.value;
});
colorPicker.addEventListener('input', (e) => {
  currentColor = e.target.value;
});

// Canvas drawing
canvas.addEventListener('mousedown', (e) => {
  isDrawing = true;
  ctx.beginPath();
  ctx.moveTo(e.offsetX, e.offsetY);
});
canvas.addEventListener('mousemove', (e) => {
  if (!isDrawing) return;
  ctx.lineWidth = brushSize;
  ctx.strokeStyle = currentColor;
  ctx.fillStyle = currentColor;

  switch (brushType) {
    case 'spray':
      for (let i = 0; i < 20; i++) {
        const offsetX = Math.random() * brushSize - brushSize / 2;
        const offsetY = Math.random() * brushSize - brushSize / 2;
        ctx.fillRect(e.offsetX + offsetX, e.offsetY + offsetY, 1, 1);
      }
      break;
    case 'pixel':
      ctx.fillRect(e.offsetX, e.offsetY, brushSize, brushSize);
      break;
    default:
      ctx.lineTo(e.offsetX, e.offsetY);
      ctx.stroke();
      break;
  }
});
canvas.addEventListener('mouseup', () => { isDrawing = false; ctx.closePath(); });
canvas.addEventListener('mouseout', () => { isDrawing = false; ctx.closePath(); });

// Eraser and clear
document.getElementById('eraser').addEventListener('click', () => {
  currentColor = '#FFFFFF';
});
document.getElementById('clearCanvas').addEventListener('click', () => {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  uploadedImage = null;
});

// Load uploaded image
document.getElementById('loadImage').addEventListener('click', () => {
  const fileInput = document.getElementById('uploadImage');
  const file = fileInput.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = function (event) {
      const img = new Image();
      img.onload = function () {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        uploadedImage = img;
      };
      img.src = event.target.result;
    };
    reader.readAsDataURL(file);
  } else {
    alert("Please select an image file.");
  }
});

// Stylize with selected style
document.getElementById('stylizeBtn').addEventListener('click', () => {
  const drawingData = canvas.toDataURL('image/png');
  const style = document.getElementById('styleSelector').value;

  fetch('/stylize', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ drawingData: drawingData, style: style })
  })
    .then(res => res.json())
    .then(data => {
      if (data.styled_image) {
        const img = new Image();
        img.src = data.styled_image; // Already base64 prefix included
        document.getElementById('styledImageContainer').innerHTML = '';
        document.getElementById('styledImageContainer').appendChild(img);
        messageDiv.textContent = "Stylize complete!";
      } else {
        console.error(data.error);
        messageDiv.textContent = "Error: " + data.error;
      }
    })
    .catch(error => {
      console.error(error);
      messageDiv.textContent = "Stylize failed.";
    });
});

// Convert to 3D and provide download link + viewer
document.getElementById('toggleView').addEventListener('click', () => {
  const drawingData = canvas.toDataURL('image/png');

  fetch('/convert', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ drawingData: drawingData })
  })
    .then(res => res.json())
    .then(data => {
      if (data.download_url) {
        // Show download link
        download3DLink.href = data.download_url;
        download3DLink.style.display = 'inline-block';
        download3DLink.textContent = "Download 3D Model";

        // Set last model name for viewer
        lastGeneratedModel = data.download_url.split('/').pop();
        open3DViewerBtn.style.display = 'inline-block';

        messageDiv.textContent = data.message;
      } else {
        console.error(data.error || data.message);
        messageDiv.textContent = "Error: " + (data.error || data.message);
      }
    })
    .catch(error => {
      console.error(error);
      messageDiv.textContent = "3D conversion failed.";
    });
});

// Open 3D Viewer
open3DViewerBtn.addEventListener('click', () => {
  window.open(`/view_3d?model=${lastGeneratedModel}`, '_blank');
});
