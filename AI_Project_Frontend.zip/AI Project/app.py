from flask import Flask, render_template, request, jsonify
import requests
import os
import base64

app = Flask(__name__)


REMOTE_SERVER_URL = "https://043d-194-95-61-252.ngrok-free.app" # Paste the link from ngrok tunnel here! each time when you get a new link

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/stylize", methods=["POST"])
def stylize():
    drawing_data = request.json.get("drawingData")
    style = request.json.get("style")

    response = requests.post(
        f"{REMOTE_SERVER_URL}/stylize",
        json={"drawingData": drawing_data, "style": style}
    )
    return jsonify(response.json())

@app.route('/convert', methods=['POST'])
def convert():
    
    data = request.get_json()
    drawing_data = data.get('drawingData')

    input_filename = 'temp_input.png'
    with open(os.path.join('static', input_filename), 'wb') as f:
        f.write(base64.b64decode(drawing_data.split(',')[1]))

    output_filename = 'output_3d.glb'
    output_path = os.path.join('static', output_filename)

    return jsonify({
        "download_url": f"/static/{output_filename}",
        "message": "3D model generated! Click to download."
    })


@app.route("/view_3d")
def view_3d():
    return render_template("view_3d.html")

if __name__ == "__main__":
    app.run(port=5000, debug=True)
